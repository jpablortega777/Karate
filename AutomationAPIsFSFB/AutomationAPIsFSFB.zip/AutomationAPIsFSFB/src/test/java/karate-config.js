

function fn(){
//var encrypted = CryptoJS.AES.encrypt("Hola mundo", "secret-key");

    var config = {
        baseURL : 'https://fsfb.azure-api.net/agendamiento/informacion-paciente',
        privateKey : "395e06b3-0c0b-47f2-a526-371691616f82",
        timestamp : Math.round(new Date().getTime() / 1000),
        tipo_documento : "4",
        numero_documento : "1026278527",
        //md5 : CryptoJS.MD5(tipo_documento + "~" + numero_documento + "~" + timestamp + "~" + privateKey),
        //md5 : CryptoJS.AES.encrypt("hola mundo","secret-key"),
        //md5 : encrypted.toString(),
        //payload : CryptoJS.SHA1(md5 + "")

    };
    //karate.log(encrypted.toString());
    //karate.configure('java.security', {allowAllAccess: true});
    //karate.configure('security.java', { allow: ['security'] });
    karate.configure('connectTimeout', 5000);
    karate.configure('readTimeout', 5000);
    return config;
}
