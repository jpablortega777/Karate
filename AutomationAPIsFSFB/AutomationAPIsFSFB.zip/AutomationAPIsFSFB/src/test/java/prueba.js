
function printConfig() {
    //var config = "Hola mundo"; // Llamada a la función fn() para obtener la configuración
var encrypted = CryptoJS.AES.encrypt("Hola mundo", "secret-key");
    karate.log(encrypted.toString()); // Imprimir la configuración en la consola
}
